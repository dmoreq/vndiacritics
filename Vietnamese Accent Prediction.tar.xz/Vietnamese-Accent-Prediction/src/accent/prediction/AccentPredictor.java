package accent.prediction;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import utils.Utils;


public class AccentPredictor {

	private NGram ONE_GRAM;
	private NGram TWO_GRAM;
	private Accent ACCENT;
	double MIN = -1000;

	public AccentPredictor(String _1GramFile, String _2GramsFile) {
		System.out.println("Loading NGrams...");
		ACCENT = new Accent("datasets/AccentInfo.tsv");
		ONE_GRAM = new NGram(_1GramFile,true);
		TWO_GRAM = new NGram(_2GramsFile,false);
		System.out.println("Done!");
	}
	
	public AccentPredictor() {
		System.out.println("Loading NGrams...");
		ACCENT = new Accent("datasets/AccentInfo.tsv");
		ONE_GRAM = new NGram("datasets/news1gram_viwiki.tsv",true);
		TWO_GRAM = new NGram("datasets/news2grams_viwiki.tsv",false);
		System.out.println("Done!");
	}

	public Double scoreATwoGram(String firstGram, String secondGram, boolean isFirst){
		int number2Gram = TWO_GRAM.getFrequencyOf(firstGram + " " + secondGram);
		int number1Gram = ONE_GRAM.getFrequencyOf(firstGram);

		double log;
		if(number1Gram > 0 && number2Gram > 0)
			log = Math.log((double) (number2Gram + 1) / (number1Gram + TWO_GRAM.getFirstGramFrequencyOf(firstGram)));
		else
			log = Math.log(1.0 / (2 * (TWO_GRAM.size + TWO_GRAM.totalCount)));
		if(isFirst) {
			log += Math.log((double)(number1Gram + 1)/(ONE_GRAM.size + ONE_GRAM.totalCount));
		}
		return log;
	}

	private String makePrediction(List<List<String>> possibles,Map<Integer,
		Map<Integer, Double>> scoreBoard,
		Map<Integer, Map<Integer, Integer>> tracer ){
		int possibleSize = possibles.size();
		double max = MIN;
		int traceIndex = 0;

		for (int i = 0; i < possibles.get(possibleSize-1).size(); i++) {
			if (max <= scoreBoard.get(possibleSize - 1).get(i)) {
				max = scoreBoard.get(possibleSize - 1).get(i);
				traceIndex = i;
			}
		}
		String result = possibles.get(possibleSize - 1).get(traceIndex);
		traceIndex = tracer.get(possibleSize - 1).get(traceIndex);
		int index = possibleSize - 2;
		while (index >= 0) {
			result = possibles.get(index).get(traceIndex) + " " + result;
			traceIndex = tracer.get(index).getOrDefault(traceIndex,0);
			index = index-1;
		}
		return result;
	}
	private String dynamicProgramming(List<List<String>> possibles){
		Map<Integer, Map<Integer, Double>> scoreBoard = new HashMap<>();
		Map<Integer, Map<Integer, Integer>> tracer = new HashMap<>();
		for (int i = 0; i < possibles.size(); i++) {
			scoreBoard.put(i,new HashMap<>());
			tracer.put(i,new HashMap<>());
		}
		for (int i = 0; i < possibles.get(0).size(); i++)
			scoreBoard.get(0).put(i,0.0);

		for (int i = 1; i < possibles.size(); i++) {
			for (int j = 0; j < possibles.get(i).size(); j++) {
				scoreBoard.get(i).put(j,MIN);
				for (int k = 0; k < possibles.get(i-1).size(); k++) {
					String recentGram = possibles.get(i).get(j);
					String lastGram = possibles.get(i - 1).get(k);
					double score = scoreATwoGram(lastGram,recentGram,i==1);
					double value = scoreBoard.get(i - 1).getOrDefault(k,0.0) + score;
					if (scoreBoard.get(i).get(j) < value) {
						scoreBoard.get(i).put(j,value);
						tracer.get(i).put(j,k);
					}
				}
			}
		}
		return makePrediction(possibles,scoreBoard,tracer);
	}
	public String predictAccents(String inputContent) {
		String[] inputSentence = inputContent.split("[\\.\\!\\,\n\\;\\?]");
		StringBuffer output = new StringBuffer();
		for (String input : inputSentence) {
			String in = Utils.normaliseString(input);
			String lowercaseIn = in.toLowerCase();
			String[] words = lowercaseIn.split(" ");

			if (words.length == 1) {
				int max = 0;
				String sure = words[0];
				List<String> possibleAccents = ACCENT.generatePossibleAccentsOf(sure, ONE_GRAM);
				for (String word : possibleAccents) {
					int number1GRam = ONE_GRAM.getFrequencyOf(word);
					if (max < number1GRam) {
						max = number1GRam;
						sure = word;
					}
				}
				output.append(sure.trim() + "\n");
		} else {
				List<List<String>> possibleChangeMatrix = new LinkedList<>();
				for (int i = 0; i < words.length; i++) {
					List<String> possibleChanges = ACCENT.generatePossibleAccentsOf(words[i], ONE_GRAM);
					if (possibleChanges.size() == 0)
						possibleChanges.add(words[i]);
					possibleChangeMatrix.add(possibleChanges);
				}
				String result = dynamicProgramming(possibleChangeMatrix);
				output.append(processOutput(in, result).trim() + "\n");
			}
		}
		return output.toString().trim();
	}

	private String processOutput(String input, String output) {
		StringBuffer str = new StringBuffer();
		for(int i = 0; i < input.length(); i++) {
			char inputChar = input.charAt(i);
			char outputChar = output.charAt(i);
			if(Character.isUpperCase(inputChar))
				str.append(Character.toUpperCase(outputChar));
			else str.append(outputChar);
			
		}	
		return str.toString();
	}
	
	public static void main(String[] args) throws IOException {
		AccentPredictor ap = new AccentPredictor(); // Load default n-grams files
//		AccentPredictor ap = new AccentPredictor("datasets/news1gram", "datasets/new2grams"); // Using your own data

		while (true) {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in, "utf8"));
			System.out.println("===============================================");
			System.out.print("Nhập vào chuỗi ký tự:");
			String s = (br.readLine());
			System.out.println((s));
			System.out.print("\nKết quả:");
			System.out.println(ap.predictAccents(s));
			System.out.println("===============================================");
		}
	}
}
