package accent.prediction;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Accent {
  private Map<Character,String> ACCENT_DICT;

  public Accent(String textFile){
    ACCENT_DICT = getAccentInfo(textFile);
  }

  public Map<Character,String> getAccentInfo(String fileIn) {
    Map output = new HashMap();
    try(BufferedReader bufferedReader = Files.newBufferedReader(Paths.get(fileIn))) {
      while (bufferedReader.ready()) {
        String line = bufferedReader.readLine();
        if (line != null && line.trim().length() > 0) {
          String[] cols = line.split("\t");
          Character key = cols[0].charAt(0);
          String value = cols[1];
          output.put(key,value);
        }
      }
    } catch (IOException e) {

    }
    return output;
  }

  public Set<String> generatePossibleAccents(Set<String> currentStates, String alternativeAccents){
    Set output = new TreeSet<String>();
    for ( String state: currentStates){
      for ( Character c: alternativeAccents.toCharArray()){
        output.add(state+c.toString());
      }
    }
    return output;
  }

  public List<String> generatePossibleAccentsOf(String word,NGram ONEGRAM){
    Set<String> output = new TreeSet();
    output.add("");
    for( Character c : word.toCharArray()){
      if ( ACCENT_DICT.containsKey(c) ){
        output = generatePossibleAccents(output,ACCENT_DICT.get(c));
      }else{
        output = generatePossibleAccents(output,c.toString());
      }
    }
    return output.stream()
        .filter(it->ONEGRAM.containsKey(it))
        .collect(Collectors.toList());
  }
}
