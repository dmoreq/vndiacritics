package accent.prediction;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class NGram {
  public final long size;
  public final long totalCount;
  private final String SEPARATOR = "\t";
  private Map<String, Integer> frequency;
  private Map<String, Integer> firstGramFrequency;

  public NGram(String textFile, boolean isOneGram){
    frequency = loadNGram(textFile);
    size = calculateSize();
    totalCount = calculateTotalCount();
    if ( !isOneGram ){
      firstGramFrequency = calculateFirstGramFrequency();
    }
  }

  public boolean containsKey(String key){
    return frequency.containsKey(key);
  }

  public Integer getFrequencyOf(String key){
    return frequency.getOrDefault(key,0);
  }

  public Integer getFirstGramFrequencyOf(String key){
    return firstGramFrequency.getOrDefault(key,0);
  }

  private Map<String, Integer> calculateFirstGramFrequency(){
    return frequency.keySet()
        .parallelStream()
        .map(it -> it.split(" ")[0])
        .collect(
            Collectors.toConcurrentMap(
              w -> w, w -> 1, Integer::sum)
        );
  }

  private long calculateTotalCount(){
    return frequency.values().stream().map(it -> Long.valueOf(it)).reduce(0L,Long::sum);
  }

  private long calculateSize(){
    return frequency.size();
  }

  private Map<String, Integer> loadNGram(String textFile){
    Map ngrams = new HashMap<String, Integer>();
    try(BufferedReader bufferedReader = Files.newBufferedReader(Paths.get(textFile))) {
      while (bufferedReader.ready()) {
        String line = bufferedReader.readLine();
        String ngramWord = line.split(SEPARATOR)[0];
        int ngramCount = Integer.parseInt(line.split(SEPARATOR)[1]);
        ngrams.put(ngramWord, ngramCount);
      }
    } catch (IOException e) {

    }
    return ngrams;
  }
}
